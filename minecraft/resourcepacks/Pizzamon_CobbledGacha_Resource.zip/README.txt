Modified version of a template resourcepack for CobbledGacha, customized for the Pizzamon modpack by NFinET_Owa.

Version 1

Current changes:
- 4 new custom hand-made textures available, amulet_coin.png, meowth_capsule.png, meowth_galar_capsule.png, and meowth_alola_capsule.png [ assets/cobbledgacha/textures/item ]

- [ assets/cobbledgacha/lang/en_us.json ]
-- Gacha_machine_5 renamted to "Game Corner PAYDAY Machine" (was Citrine Poke Gacha Machine)
-- Gacha_coin_2 renamed to "Cram O'Matic Token" (was Erratic Gacha Coin)
-- Gacha_coin_3 renamed to "Item Printer Token" (was Blueberry Gacha Coin)
-- Gacha_coin_5 renamed to "Game Corner Token" (was Citrine Gacha Coin)
Modified version of CobbleTowns: Continued 1.1.3.
This datapack was made because of issues getting CobbleTowns to function properly while also replacing its shops with ones using the CobbleDollars mod for Cobblemon 1.7.x+
This datapack was made for the Pizzamon - Stuffed Crust Pizza Pack by NFinET_Owa and shop inventories and prices have been selected for said pack, and requires:
- Cobblemon
- CobbleDollars
- Cobblemon Additions
- Cobblemon: Max Repel 